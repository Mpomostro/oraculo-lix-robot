# ORÁCULO-LIX | EXECUÇÃO STANDALONE (SEM FLASK)
import random, time, math, csv, os
from collections import deque, Counter
import numpy as np

CORES = ["BRANCO", "VERMELHO", "PRETO"]
COR_IDX = {c:i for i,c in enumerate(CORES)}
IDX_COR = {i:c for c,i in COR_IDX.items()}
CICLO = 3
ENTROPIA_MAX_SEGURA = 0.65
CONFIANCA_MIN = 60
HIST_FILE = "historico.csv"

class Neural:
    def __init__(self):
        self.w = np.random.randn(3,3) * 0.1
    def prever(self, x):
        return int(np.argmax(self.w @ x))
    def treinar(self, x, y):
        p = self.prever(x)
        if p != y:
            self.w[y] += 0.05 * x
            self.w[p] -= 0.05 * x

class Linha:
    def __init__(self, i):
        self.id = i
        self.hist = deque(maxlen=200)
        self.entropia = 1.0
    def gerar(self):
        r = random.random()
        if r < 0.07: return "BRANCO"
        return "VERMELHO" if r < 0.535 else "PRETO"
    def passo(self):
        self.hist.append(self.gerar())
        self.entropia = self.calc_entropia()
    def calc_entropia(self):
        if len(self.hist) < 10:
            return 1.0
        c = Counter(self.hist)
        t = sum(c.values())
        e = 0
        for v in c.values():
            p = v/t
            e -= p * math.log(p + 1e-9)
        return round(e / math.log(3), 3)

class Oraculo:
    def __init__(self):
        self.linhas = [Linha(i) for i in range(5)]
        self.rede = Neural()
        self.rodada = 0
        if not os.path.exists(HIST_FILE):
            with open(HIST_FILE,"w",newline="") as f:
                csv.writer(f).writerow(["rodada","entropia","previsao","resultado"])
    def vetor(self, h):
        v = np.zeros(3)
        for c in h:
            v[COR_IDX[c]] += 1
        return v / (np.sum(v)+1e-9)
    def ciclo(self):
        for l in self.linhas:
            l.passo()
        ativa = min(self.linhas, key=lambda x:x.entropia)
        x = self.vetor(ativa.hist)
        y = COR_IDX[ativa.hist[-1]]
        self.rede.treinar(x,y)
        previsao = IDX_COR[self.rede.prever(x)]
        with open(HIST_FILE,"a",newline="") as f:
            csv.writer(f).writerow([self.rodada, ativa.entropia, previsao, ativa.hist[-1]])
        self.rodada += 1
        print(f"Ciclo {self.rodada} | Previsão: {previsao} | Entropia: {ativa.entropia}")

if __name__ == "__main__":
    orc = Oraculo()
    while True:
        orc.ciclo()
        time.sleep(CICLO)
